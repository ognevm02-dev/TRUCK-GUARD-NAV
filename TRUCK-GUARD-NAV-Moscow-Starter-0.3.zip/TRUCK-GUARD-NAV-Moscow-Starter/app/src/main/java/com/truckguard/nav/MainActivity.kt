package com.truckguard.nav

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.speech.tts.TextToSpeech
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import java.util.Locale

class MainActivity : Activity(), LocationListener, TextToSpeech.OnInitListener {
    private lateinit var locationText: TextView
    private lateinit var statusText: TextView
    private lateinit var locationManager: LocationManager
    private var tts: TextToSpeech? = null
    private val requestCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13, 18, 25)
        window.navigationBarColor = Color.rgb(13, 18, 25)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 16)
            setBackgroundColor(Color.rgb(13, 18, 25))
        }
        fun label(value: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply { text = value; textSize = size; setTextColor(color); setPadding(0, 7, 0, 7) }

        root.addView(label("TRUCK GUARD NAV", 25f))
        root.addView(label("МОСКВА И МОСКОВСКАЯ ОБЛАСТЬ • СТАРТОВАЯ ВЕРСИЯ", 11f, 0xFF9FB3C8.toInt()))
        root.addView(label("ТЯГАЧ + ПОЛУПРИЦЕП | ВЫСОТА 3,9 м | МАССА 40 т", 14f, 0xFF55D6A0.toInt()))
        statusText = label("GPS: проверка…", 14f, 0xFFFFC857.toInt())
        root.addView(statusText)
        locationText = label("Координаты пока не получены", 13f, 0xFFB9C7D5.toInt())
        root.addView(locationText)

        val map = WebView(this).apply {
            settings.javaScriptEnabled = false
            webViewClient = WebViewClient()
            setBackgroundColor(Color.rgb(30, 38, 47))
            loadUrl("https://www.openstreetmap.org/#map=9/55.7512/37.6184")
        }
        root.addView(map, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(Button(this).apply { text = "ОБНОВИТЬ GPS"; setOnClickListener { requestGps() } })
        root.addView(Button(this).apply {
            text = "ГОЛОСОВАЯ ПРОВЕРКА"
            setOnClickListener { tts?.speak("TRUCK GUARD NAV. Проверка голосового сопровождения.", TextToSpeech.QUEUE_FLUSH, null, "test") }
        })
        root.addView(label("ВАЖНО: прототип показывает онлайн-карту и GPS, но НЕ строит грузовые маршруты и НЕ проверяет мосты, массу или запреты. Не используйте его как основной навигатор.", 12f, 0xFFFFC857.toInt()))
        setContentView(root)
        requestGps()
    }

    private fun requestGps() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCode)
            statusText.text = "GPS: требуется разрешение"
            return
        }
        try {
            val enabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
            statusText.text = if (enabled) "GPS: включён, ожидаем координаты…" else "GPS: выключен в настройках"
            if (enabled) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 5f, this)
            val last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (last != null) onLocationChanged(last)
        } catch (_: Exception) { statusText.text = "GPS: не удалось получить данные" }
    }
    override fun onLocationChanged(location: Location) {
        locationText.text = "Широта: %.6f   Долгота: %.6f\nТочность: примерно %.0f м".format(Locale.US, location.latitude, location.longitude, location.accuracy)
        statusText.text = "GPS: координаты получены"
    }
    @Deprecated("Deprecated in Android API")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) { statusText.text = "GPS: приёмник включён" }
    override fun onProviderDisabled(provider: String) { statusText.text = "GPS: приёмник выключен" }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU") }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) requestGps()
    }
    override fun onDestroy() {
        try { locationManager.removeUpdates(this) } catch (_: Exception) {}
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
